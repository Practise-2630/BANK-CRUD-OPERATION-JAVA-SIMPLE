package com.bt.Accountdao;
import com.bt.config.*;
import com.bt.model.*;
import com.bt.BankMain.*;

public class AccountDao {
	
public 	String AccountCreate(Account acc)
{
	Config.getConnection();
	return null;
	
}

}
